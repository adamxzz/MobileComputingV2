package com.example.digimonapp.data

import android.os.Parcel
import java.util.*
import android.os.Parcelable

class DigimonEntity (
    var name: String?,
    var img: String?,
    var level: String?,
) : Parcelable
{
    constructor(parcel: Parcel) : this(
        parcel.readString(),
        parcel.readString(),
        parcel.readString()
    ) {
    }

    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeString(name)
        parcel.writeString(img)
        parcel.writeString(level)
    }

    override fun describeContents(): Int {
        return 0
    }

    companion object CREATOR : Parcelable.Creator<DigimonEntity> {
        override fun createFromParcel(parcel: Parcel): DigimonEntity {
            return DigimonEntity(parcel)
        }

        override fun newArray(size: Int): Array<DigimonEntity?> {
            return arrayOfNulls(size)
        }
    }
}