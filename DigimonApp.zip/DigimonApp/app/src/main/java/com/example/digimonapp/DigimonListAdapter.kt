package com.example.digimonapp

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.digimonapp.data.DigimonEntity
import com.example.digimonapp.databinding.ListItemBinding

class DigimonListAdapter (private val digimonsList: List<DigimonEntity>,
                          private val listener: ListItemListener) :

    RecyclerView.Adapter<DigimonListAdapter.ViewHolder>() {

    val selectedDigimons = arrayListOf<DigimonEntity>()

    inner class ViewHolder(itemView: View) :
        RecyclerView.ViewHolder(itemView) {
        val binding = ListItemBinding.bind(itemView)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val inflater = LayoutInflater.from(parent.context)

        val view = inflater.inflate(R.layout.list_item, parent, false)
        return ViewHolder(view)
    }


    override fun getItemCount() = digimonsList.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val digimon = digimonsList[position]
        with(holder.binding) {

            digimonName.text = digimon.name
            root.setOnClickListener{
                listener.onItemClick(digimon)
            }

        }

    }
    interface ListItemListener {
        fun onItemClick(digimon: DigimonEntity)
    }


}