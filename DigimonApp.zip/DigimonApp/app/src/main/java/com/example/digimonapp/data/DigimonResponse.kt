package com.example.digimonapp.data

class DigimonResponse(
    var name : List<DigimonEntity>

)