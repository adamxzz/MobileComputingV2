package com.example.digimonapp.dataaccess

//import com.example.digimonapp.data.DigimonEntity
import com.example.digimonapp.data.DigimonResponse
import retrofit2.Response
import retrofit2.http.GET

interface DigimonApi {

    @GET("digimon/")
    suspend fun getDigimons() : DigimonResponse
}
