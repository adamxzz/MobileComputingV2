package com.example.digimonapp

import androidx.lifecycle.ViewModel

class EditorViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}