package com.example.digimonapp

const val NEW_DIGIMON_ID = 0
const val TAG = "Digimon Logging"
const val COCKTAIL_TEXT_KEY = "digimonTextKey"
const val CURSOR_POSITION_KEY = "cursorPositionKey"
const val SELECTED_COCKTAILS_KEY = "selectedDigimonKey"

const val WEB_SERVICE_URL = "https://digimon-api.vercel.app/"