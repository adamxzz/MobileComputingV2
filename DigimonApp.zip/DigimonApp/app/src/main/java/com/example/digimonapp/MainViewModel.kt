package com.example.digimonapp

import android.util.Log
import androidx.lifecycle.*
import com.example.digimonapp.data.DigimonEntity
import com.example.digimonapp.dataaccess.RetrofitInstance
import kotlinx.coroutines.launch

class MainViewModel : ViewModel()  {

    private val _digimons: MutableLiveData<List<DigimonEntity>> = MutableLiveData()

    val digimons: LiveData<List<DigimonEntity>>
        get() = _digimons

    private val _isLoading = MutableLiveData(false)
    val isLoading: LiveData<Boolean>
        get() = _isLoading


    init {
        getDigimons()
    }

    private fun getDigimons() {
        viewModelScope.launch {
            _isLoading.value = true
            val fetchedDigimons = RetrofitInstance.api.getDigimons()
            Log.i(TAG, "List of Digimons : $fetchedDigimons")
            _digimons.value = fetchedDigimons.name
            _isLoading.value = false
        }
    }
}